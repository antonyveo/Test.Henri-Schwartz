﻿namespace BNPTest.Contract
{
    public enum TradeState
    {
        Rejected,
        Pending,
        Accepted
    }
}
