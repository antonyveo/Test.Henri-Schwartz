﻿namespace BNPTest.Contract
{
    public class CorrelationResult
    {
        public string CorrelationId { get; }
        public int NumberOfTrades { get; }
        public TradeState State { get; }

        public CorrelationResult(string correlationId, int numberOfTrades, TradeState state)
        {
            CorrelationId = correlationId;
            NumberOfTrades = numberOfTrades;
            State = state;
        }
    }
}
