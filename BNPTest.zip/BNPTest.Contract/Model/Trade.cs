﻿namespace BNPTest.Contract
{
    public class Trade
    {
        public string CorrelationId { get; }
        public int NumberOfTrades { get; }
        public int Limit { get; }
        public string TradeId { get; }
        public int Value { get; }

        public Trade(string correlationId, int numberOfTrades, int limit, string tradeId, int value)
        {
            CorrelationId = correlationId;
            NumberOfTrades = numberOfTrades;
            Limit = limit;
            TradeId = tradeId;
            Value = value;
        }
    }
}
