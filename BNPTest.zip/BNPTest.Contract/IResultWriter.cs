﻿using System.Collections.Generic;

namespace BNPTest.Contract
{
    public interface IResultWriter
    {
        void Write(IEnumerable<CorrelationResult> result, string filePath);
    }
}
