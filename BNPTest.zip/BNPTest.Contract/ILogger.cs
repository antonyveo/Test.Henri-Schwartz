﻿using System;

namespace BNPTest.Contract
{
    public interface ILogger
    {
        void Info(string message, Exception exception = null);
        void Warn(string message, Exception exception = null);
        void Error(string message, Exception exception = null);
    }
}
