﻿namespace BNPTest.Contract
{
    public interface ICorrelationStateCalculator
    {
        void Calulate(string xmlFilePath, string resultFilePath);
    }
}
