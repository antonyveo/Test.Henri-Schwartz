﻿using System.Collections.Generic;

namespace BNPTest.Contract
{
    public interface IXmlParser
    {
        IEnumerable<Trade> Parse(string xmlFilePath);
    }
}
