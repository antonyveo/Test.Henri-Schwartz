﻿using System;

namespace BNPTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var correlationStateCalculator = new CorrelationStateCalculator(new XmlParser(), new Logger(), new ResultWriter());
            correlationStateCalculator.Calulate(args[0], args[1]);
            Console.WriteLine("Exiting program");
            Console.WriteLine("press any key....");
            Console.ReadLine();
        }
    }
}
