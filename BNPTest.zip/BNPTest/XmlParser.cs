﻿using System;
using System.Collections.Generic;
using System.Xml;

using BNPTest.Contract;

namespace BNPTest
{
    class XmlParser : IXmlParser
    {
        private readonly XmlDocument doc;

        public XmlParser()
        {
            doc = new XmlDocument();
        }

        public IEnumerable<Trade> Parse(string xmlFilePath)
        {
            doc.Load(xmlFilePath);
            var list = new List<Trade>();
            
            foreach (XmlNode node in doc.DocumentElement.SelectSingleNode("/Trades").ChildNodes)
            {
                string correlationId = node.Attributes["CorrelationId"].Value;
                string numberOfTradesStr = node.Attributes["NumberOfTrades"].Value;
                string limitStr = node.Attributes["Limit"].Value;
                string tradeId = node.Attributes["TradeID"].Value;
                string valueStr = node.InnerText;

                if (!int.TryParse(numberOfTradesStr, out int numberOfTrades))
                {
                    var ex = new FormatException($"TradeId {tradeId} has an unparsable NumberOfTrades: {numberOfTradesStr}");
                    throw(ex);
                }

                if (!int.TryParse(limitStr, out int limit))
                {
                    var ex = new FormatException($"TradeId {tradeId} has an unparsable Limit: {limitStr}");
                    throw (ex);
                }

                if (!int.TryParse(valueStr, out int value))
                {
                    var ex = new FormatException($"TradeId {tradeId} has an unparsable value: {valueStr}");
                    throw (ex);
                }

                var trade = new Trade(correlationId, numberOfTrades, limit, tradeId, value);
                list.Add(trade);
            }

            return list;
        }
    }
}
