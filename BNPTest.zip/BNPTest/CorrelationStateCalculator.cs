﻿using System;
using System.Collections.Generic;
using System.Linq;

using BNPTest.Contract;

namespace BNPTest
{
    public class CorrelationStateCalculator : ICorrelationStateCalculator
    {
        private IXmlParser xmlParser;
        private ILogger logger;
        private IResultWriter fileWriter;

        public CorrelationStateCalculator(IXmlParser xmlParser, ILogger logger, IResultWriter fileWriter)
        {
            this.xmlParser = xmlParser;
            this.logger = logger;
            this.fileWriter = fileWriter;
        }

        public void Calulate(string xmlFilePath, string resultFilePath)
        {
            IEnumerable<Trade> trades;

            logger.Info($"Starting parsing file {xmlFilePath}...");

            try
            {
                trades = xmlParser.Parse(xmlFilePath);
            }
            catch(Exception e)
            {
                logger.Error(e.Message, e);
                logger.Warn("Stopping calculation!");
                return;
            }

            logger.Info($"Parsing done! {trades.Count()} trades found!");

            logger.Info($"Starting aggregating trades...");

            var result = new List<CorrelationResult>();

            foreach(var correlation in trades.GroupBy(t => t.CorrelationId).OrderBy(g => g.Key))
            {
                var firstTrade = correlation.First();
                TradeState state;

                int tradeCount = 0;
                int totalValue = 0;
                foreach(var trade in correlation)
                {
                    tradeCount++;
                    totalValue += trade.Value;
                }

                if(tradeCount != firstTrade.NumberOfTrades)
                {
                    state = TradeState.Pending;
                }
                else
                {
                    if(totalValue > firstTrade.Limit)
                    {
                        state = TradeState.Rejected;
                    }
                    else
                    {
                        state = TradeState.Accepted;
                    }
                }

                var correlationResult = new CorrelationResult(firstTrade.CorrelationId, firstTrade.NumberOfTrades, state);
                result.Add(correlationResult);
            }

            logger.Info($"Aggregating trades done!");

            logger.Info($"Writing results into file...");

            fileWriter.Write(result, resultFilePath);

            logger.Info($"Writing results done!");
        }
    }
}
