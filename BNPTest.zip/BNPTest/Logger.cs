﻿using System;

using BNPTest.Contract;

namespace BNPTest
{
    public class Logger : ILogger
    {
        private readonly NLog.Logger Nlog = NLog.LogManager.GetCurrentClassLogger();

        public void Error(string message, Exception exception = null)
        {
            if(exception is null)
            {
                Nlog.Error(message);
            }
            else
            {
                Nlog.Error(exception, message);
            }
        }

        public void Info(string message, Exception exception = null)
        {
            if (exception is null)
            {
                Nlog.Info(message);
            }
            else
            {
                Nlog.Info(exception, message);
            }
        }

        public void Warn(string message, Exception exception = null)
        {
            if (exception is null)
            {
                Nlog.Warn(message);
            }
            else
            {
                Nlog.Warn(exception, message);
            }
        }
    }
}
