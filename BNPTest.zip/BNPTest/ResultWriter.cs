﻿using System.Collections.Generic;
using System.IO;
using System.Text;

using BNPTest.Contract;

namespace BNPTest
{
    public class ResultWriter : IResultWriter
    {
        public void Write(IEnumerable<CorrelationResult> result, string filePath)
        {
            var stringResult = new StringBuilder();
            stringResult.AppendLine("CorrelationID,NumberOfTrades,State");

            foreach (var correlation in result)
            {
                stringResult.AppendLine($"{correlation.CorrelationId},{correlation.NumberOfTrades},{correlation.State.ToString()}");
            }

            File.WriteAllText(filePath, stringResult.ToString());
        }
    }
}
